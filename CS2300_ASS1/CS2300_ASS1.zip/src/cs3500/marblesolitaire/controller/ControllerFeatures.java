package cs3500.marblesolitaire.controller;

/**
 * This is class for helping construct the JFrame.
 */
public class ControllerFeatures {
}
