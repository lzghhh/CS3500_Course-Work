package view;

public interface ViewGUI {

  void showView(boolean show);

  void showErrorMessage(String msg);

  void setUpMenuBar();

  void setUpButtons();
}
